export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">About Us</h1>
      <div className="max-w-2xl mx-auto">
        <p className="mb-4">
          Welcome to TheSmartStories, your go-to destination for high-quality eBooks that empower you to learn, grow,
          and succeed in various aspects of life and business.
        </p>
        <p className="mb-4">
          Our mission is to provide accessible, valuable knowledge to help you unlock your potential and achieve your
          goals. Whether you're looking to improve your personal skills, boost your career, or grow your business, we
          have carefully curated eBooks to support your journey.
        </p>
        <p className="mb-4">
          At TheSmartStories, we believe in the power of continuous learning and self-improvement. That's why we
          collaborate with expert authors and thought leaders to bring you the most up-to-date and practical information
          in an easy-to-digest format.
        </p>
        <p>
          Join our community of lifelong learners and start your journey to success today with our premium eBooks.
          Remember, knowledge is power, and we're here to help you harness it!
        </p>
      </div>
    </div>
  )
}

