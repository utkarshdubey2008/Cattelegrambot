"use client"

import { motion } from "framer-motion"
import BookCard from "../components/BookCard"
import { books } from "../data/books"

const fadeIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
}

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
}

export default function BrowsePage() {
  return (
    <div className="bg-gray-100 min-h-screen pb-20">
      <div className="container mx-auto px-4 py-8">
        <motion.h1 className="text-3xl font-bold text-center mb-8 text-gray-800" {...fadeIn}>
          Browse All eBooks
        </motion.h1>
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          variants={stagger}
          initial="initial"
          animate="animate"
        >
          {books.map((book) => (
            <motion.div key={book.id} variants={fadeIn}>
              <BookCard book={book} />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  )
}

