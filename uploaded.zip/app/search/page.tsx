import { Suspense } from "react"
import { notFound } from "next/navigation"
import BookCard from "../components/BookCard"
import { books } from "../data/books"

function SearchResults({ query }: { query: string }) {
  const filteredBooks = books.filter(
    (book) =>
      book.title.toLowerCase().includes(query.toLowerCase()) ||
      book.author.toLowerCase().includes(query.toLowerCase()) ||
      book.description.toLowerCase().includes(query.toLowerCase()),
  )

  if (filteredBooks.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-[#666666]">No results found for "{query}"</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {filteredBooks.map((book) => (
        <BookCard key={book.id} book={book} />
      ))}
    </div>
  )
}

export default function SearchPage({
  searchParams,
}: {
  searchParams: { q: string }
}) {
  const query = searchParams.q

  if (!query) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-6 max-w-4xl">
      <h1 className="text-xl font-semibold text-[#333333] mb-4">Search results for "{query}"</h1>
      <Suspense fallback={<div>Loading...</div>}>
        <SearchResults query={query} />
      </Suspense>
    </div>
  )
}

