"use client"

import { motion } from "framer-motion"
import { books } from "@/app/data/books"
import CheckoutSteps from "@/app/components/CheckoutSteps"
import { notFound } from "next/navigation"

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
}

export default function CheckoutPage({ params }: { params: { id: string } }) {
  const book = books.find((b) => b.id === Number.parseInt(params.id))

  if (!book) {
    notFound()
  }

  return (
    <motion.div
      className="min-h-screen bg-gray-50 py-8"
      initial="hidden"
      animate="visible"
      variants={{
        visible: { transition: { staggerChildren: 0.3 } },
      }}
    >
      <motion.div variants={fadeIn}>
        <CheckoutSteps book={book} />
      </motion.div>
    </motion.div>
  )
}

