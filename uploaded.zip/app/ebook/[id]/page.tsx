"use client"

import { useEffect } from "react"
import { motion, useAnimation } from "framer-motion"
import { useInView } from "react-intersection-observer"
import Link from "next/link"
import { Star, Check } from "lucide-react"
import { books } from "../../data/books"
import { notFound } from "next/navigation"
import ImageSlider from "../../components/ImageSlider"

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
}

export default function EbookPage({ params }: { params: { id: string } }) {
  const book = books.find((b) => b.id === Number.parseInt(params.id))

  if (!book) {
    notFound()
  }

  const bookImages = [book.image, book.backCover, book.additionalImage].filter(Boolean) as string[]
  const imageTitles = bookImages.map((_, index) => `${book.title} - Image ${index + 1}`)

  const controls = useAnimation()
  const [ref, inView] = useInView()

  useEffect(() => {
    if (inView) {
      controls.start("visible")
    }
  }, [controls, inView])

  return (
    <motion.div
      className="container mx-auto px-4 py-8 max-w-4xl"
      initial="hidden"
      animate="visible"
      variants={{
        visible: { transition: { staggerChildren: 0.3 } },
      }}
    >
      <motion.div className="bg-white rounded-lg shadow-lg overflow-hidden" variants={fadeIn}>
        <div className="md:flex">
          <motion.div className="md:w-1/2 p-6" variants={fadeIn}>
            <ImageSlider images={bookImages} titles={imageTitles} />
          </motion.div>
          <motion.div className="md:w-1/2 p-6" variants={fadeIn}>
            <motion.div variants={fadeIn}>
              <div className="flex items-center gap-2 mb-2">
                <span className="bg-blue-600 text-white px-2 py-1 rounded text-sm font-semibold">{book.type}</span>
                {book.rating && (
                  <div className="flex items-center text-yellow-500">
                    <Star className="w-4 h-4 fill-current" />
                    <span className="ml-1 text-sm font-semibold">{book.rating}</span>
                  </div>
                )}
                {book.reviews && <span className="text-sm text-gray-600">({book.reviews} reviews)</span>}
              </div>
              <h1 className="text-3xl font-bold text-gray-800 mb-2">{book.title}</h1>
              <p className="text-gray-600 mb-4">by {book.author}</p>
            </motion.div>
            <motion.div className="prose prose-lg max-w-none mb-6" variants={fadeIn}>
              <p className="text-gray-700">{book.description}</p>
            </motion.div>
            <motion.div className="mb-6" variants={fadeIn}>
              <div className="text-3xl font-bold text-blue-600 mb-2">₹{book.currentPrice}</div>
              <div className="flex items-center gap-2">
                <span className="text-gray-600 line-through">₹{book.originalPrice}</span>
                <span className="text-green-600 font-semibold">
                  {Math.round(((book.originalPrice - book.currentPrice) / book.originalPrice) * 100)}% OFF
                </span>
              </div>
              {book.specialOffer && <div className="mt-2 text-red-600 font-semibold">{book.specialOffer}</div>}
            </motion.div>
            <motion.div variants={fadeIn}>
              <Link href={`/checkout/${book.id}`}>
                <motion.button
                  className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold text-lg mb-6 hover:bg-blue-700 transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Buy Now
                </motion.button>
              </Link>
            </motion.div>
            {book.features && (
              <motion.div className="border-t border-gray-200 pt-6" variants={fadeIn}>
                <h2 className="text-xl font-semibold text-gray-800 mb-4">What You'll Get</h2>
                <ul className="grid gap-3">
                  {book.features.map((feature, index) => (
                    <motion.li key={index} className="flex items-center gap-2" variants={fadeIn} custom={index}>
                      <Check className="w-5 h-5 text-green-600" />
                      <span className="text-gray-700">{feature}</span>
                    </motion.li>
                  ))}
                </ul>
              </motion.div>
            )}
          </motion.div>
        </div>
      </motion.div>
    </motion.div>
  )
}

