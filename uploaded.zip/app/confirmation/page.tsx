"use client"

import { useEffect } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import confetti from "canvas-confetti"

export default function ConfirmationPage() {
  useEffect(() => {
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
    })
  }, [])

  return (
    <div className="container mx-auto py-16 text-center">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <h1 className="text-4xl font-bold mb-4">🎉 Your Order is Complete!</h1>
        <p className="text-xl mb-8">We will email you the eBook soon!</p>
        <Link href="/">
          <motion.button
            className="bg-blue-600 text-white px-6 py-3 rounded-lg font-bold"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Back to Store
          </motion.button>
        </Link>
      </motion.div>
    </div>
  )
}

