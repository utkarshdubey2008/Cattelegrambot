import { Mail, Send } from "lucide-react"

export default function ContactPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Contact Us</h1>
      <div className="max-w-md mx-auto">
        <p className="mb-6 text-center">
          We'd love to hear from you! If you have any questions, suggestions, or just want to say hello, feel free to
          reach out to us using the contact information below.
        </p>
        <div className="space-y-4">
          <div className="flex items-center justify-center">
            <Mail className="mr-2 h-6 w-6" />
            <a href="mailto:smartstoriesig@gmail.com" className="text-blue-600 hover:underline">
              smartstoriesig@gmail.com
            </a>
          </div>
          <div className="flex items-center justify-center">
            <Send className="mr-2 h-6 w-6" />
            <a
              href="https://t.me/smartstoriesyt"
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline"
            >
              t.me/smartstoriesyt
            </a>
          </div>
        </div>
        <p className="mt-8 text-center text-sm text-gray-600">
          We typically respond within 24-48 hours. Thank you for your patience and interest in TheSmartStories!
        </p>
      </div>
    </div>
  )
}

