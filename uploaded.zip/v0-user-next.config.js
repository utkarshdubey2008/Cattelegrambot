/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["envs.sh"],
  },
}

module.exports = nextConfig

